package quiz;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

@SuppressWarnings("unused")

public class KBCQuiz {
	String questions, options, answer, enter;
	char ch;
	int i, correct = 0;
	KBCQuiz[] quiz=new KBCQuiz[5];
	int count = 0;
	
	//KbcQuizStart
	public void KbcQuizStart()
	{
		for(i=0; i<5; i++) 
		{
			quiz[i] = new KBCQuiz();
		}
		
	}
	//kbcQuizMcq
		public void kbcQuizMcq()
		{
	        try
	        {
	            quiz[0].questions="Which is a valid keyword in java?";
	            quiz[1].questions="What is the name of the method used to start a thread execution?";
	            quiz[2].questions="Which interface does java.util.Hashtable implement?";
	            quiz[3].questions="Which is true about a method-local inner class?";
	            quiz[4].questions="What is the numerical range of a char?";
	           
	        }
	        catch(ArrayIndexOutOfBoundsException e)
	        {
	        	e.printStackTrace();
	            System.err.println("Error Occur!\n"+e.getMessage());
	            System.exit(0);
	        }
	    }
		
		//kbcQuizMcqOptions
		public void kbcQuizMcqOptions()
		{
	        try
	        {
	            quiz[0].options=" A.interface \n B.string\n C.Float\n D.unsigned";
	            quiz[1].options=" A.init();\n B.start(); \n C.run();\n D.resume();";
	            quiz[2].options=" A.Java.util.Map \n B.Java.util.List \n C.Java.util.HashTable\n D.Java.util.Collection";
	            quiz[3].options=" A.It must be marked final. \n B.It can be marked abstract.\n C.It can be marked public.\n D.It can be marked static.";
	            quiz[4].options=" A.-128 to 127 \n B.-(215) to (215) - 1\n C.0 to 32767\n D.0 to 65535";

	        }
	        catch(ArrayIndexOutOfBoundsException e)
	        {
	            System.err.println("Error Occur!\n"+e.getMessage());
	            System.exit(0);
	        }
	    }
		//kbcQuizMcqAnswers
		
		public void kbcQuizMcqAnswers(){
	        quiz[0].answer="A";
	        quiz[1].answer="B";
	        quiz[2].answer="A";
	        quiz[3].answer="B";
	        quiz[4].answer="D";
	
		}
		public void runKbcQuiz(){
	        try{
	            Scanner scan = new Scanner(System.in);
	            String temp="";

	            for(i=0; i<5; i++)
	            {
	            	System.out.println("............................................................");
	                System.out.println("Question "+(i+1)+": "+quiz[i].questions+"\n"+quiz[i].options );
	                System.out.printf("Enter Your Answer:"+"\n");
	                
	                temp=scan.next();
	                ch=temp.charAt(0);
	                temp=Character.toString(ch);
	                
	                
	              
	                if(temp.equalsIgnoreCase(quiz[i].answer))
	                {
	                	System.out.println("-----------------------------------------------------------");
	                	System.out.println("Question "+(i+1));
	                    System.out.println("Entered Answer is CORRECT");
	                    correct++;
//	                    System.out.println("Correct Answer is: "+quiz[i].answer );
		                System.out.println("-----------------------------------------------------------");
	                    
	                }
	                else
	                {
	                	System.out.println("-----------------------------------------------------------");
	                	System.out.println("Question "+(i+1));
	                    System.out.println("Entered Answer is INCORRECT");
	                    System.out.println("Correct Answer is: "+quiz[i].answer );
		                System.out.println("-----------------------------------------------------------");
	                }
	                
	                
	            }
	        }
	        
	        catch(ArrayIndexOutOfBoundsException e)
	        {
	            System.err.println("Error Occur3c!\n"+e.getMessage());
	            System.exit(0);
	        }
	        catch(InputMismatchException e)
	        {
	            System.err.println("Error Occur1!\n"+e.getMessage());
	            System.exit(0);
	        }
	    }
		//Result Validation
		public void KbcQuizAssessments()
		{
			
			System.out.println("******************************************************************");
	        System.out.println("------------------ Your Final Assessment:- -----------------------");
	        System.out.println("You answered 5 questions out of \n"+correct+" Correct and \n"+(5-correct)+" Incorrect!");
	        System.out.println("*******************************************************************");
	       
	        
		}
		
		


//Main
	public static void main(String[] args) 
	{
		
		System.out.println("Name:Medidi Satyam");
		KBCQuiz Object = new KBCQuiz();
		Object.KbcQuizStart();
		Object.kbcQuizMcq();
		Object.kbcQuizMcqOptions();
		Object.kbcQuizMcqAnswers();
		Object.runKbcQuiz();
		Object.KbcQuizAssessments();    
	}
}