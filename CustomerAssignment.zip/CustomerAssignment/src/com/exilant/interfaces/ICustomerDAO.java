package com.exilant.interfaces;

import java.util.List;

import com.exilant.beans.Customer;

public interface ICustomerDAO {

	//insert
	public void insertCustomer(Customer cust);

	// delete
	public boolean deleteCustomer(int custId);

	// select all
	public List<Customer> getAllEmps();
}
