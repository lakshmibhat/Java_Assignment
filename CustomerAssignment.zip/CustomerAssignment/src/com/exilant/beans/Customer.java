package com.exilant.beans;

public class Customer {
private int custId;
private Name name;
private double income;
private Address addr;
private String email;

public Customer(){}
public Customer(int custId, Name name, double income, Address addr, String email) {
	super();
	this.custId = custId;
	this.name = name;
	this.income = income;
	this.addr = addr;
	this.email = email;
}
public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}
public Name getName() {
	return name;
}
public void setName(Name name) {
	this.name = name;
}
public double getIncome() {
	return income;
}
public void setIncome(double income) {
	this.income = income;
}
public Address getAddr() {
	return addr;
}
public void setAddr(Address addr) {
	this.addr = addr;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
@Override
public String toString() {
	return "Customer [custId=" + custId + ", name=" + name + ", income=" + income + ", addr=" + addr + ", email="
			+ email + "]";
}

}
