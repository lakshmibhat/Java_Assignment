package com.exilant.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.exilant.beans.Address;
import com.exilant.beans.Customer;
import com.exilant.beans.Name;
import com.exilant.dao.CustomerDAO;

/**
 * Servlet implementation class InsertDatatoDB
 */
@WebServlet("/InsertDatatoDB")
public class InsertDatatoDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
Customer cust = new Customer();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
if(request.getParameter("insert").equals("insert")){
	cust.setCustId(Integer.parseInt(request.getParameter("custId")));
	Name name = new Name();
	name.setfName(request.getParameter("fName"));
	name.setfName(request.getParameter("lName"));
	cust.setName(name);
	cust.setEmail(request.getParameter("email"));
	cust.setIncome(Double.parseDouble(request.getParameter("income")));
	Address addr = new Address();
	addr.sethNo(Integer.parseInt(request.getParameter("hNo")));
	addr.setStreet(request.getParameter("street"));
	addr.setCity(request.getParameter("city"));
	addr.setPin(Integer.parseInt(request.getParameter("pin")));
	cust.setAddr(addr);
	CustomerDAO custDAO = new CustomerDAO();
	custDAO.insertCustomer(cust);
	request.getRequestDispatcher("/views/CRUD.jsp");
}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
