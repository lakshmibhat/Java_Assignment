package com.exilant.dao;

import java.sql.SQLException;
import java.util.List;

import com.exilant.beans.Address;
import com.exilant.beans.Customer;
import com.exilant.beans.Name;
import com.exilant.connection.GetConnection;
import com.exilant.interfaces.ICustomerDAO;

public class CustomerDAO implements ICustomerDAO{

	@Override
	public void insertCustomer(Customer cust) {
String sql = "insert into customer values(?,?,?,?,?,?,?,?,?)";

GetConnection gc = new GetConnection();
try {
	
	gc.ps = GetConnection.getOracleConn().prepareStatement(sql);
	gc.ps.setInt(1, cust.getCustId());
	gc.ps.setString(2, cust.getName().getfName());
	gc.ps.setString(3, cust.getName().getlName());
	gc.ps.setDouble(4, cust.getIncome());
	gc.ps.setInt(5, cust.getAddr().gethNo());
	gc.ps.setString(6, cust.getAddr().getStreet());
	gc.ps.setString(7, cust.getAddr().getCity());
	gc.ps.setInt(8, cust.getAddr().getPin());
	gc.ps.setString(9, cust.getEmail());

	gc.ps.executeQuery();
	//return gc.ps.executeUpdate()>0;
} catch (SQLException e) {
	e.printStackTrace();
}finally{
	try {
		gc.ps.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
}
//return false;
	}

	@Override
	public boolean deleteCustomer(int custId) {
		GetConnection gc = new GetConnection();
		String sql ="delete from employee where custId =?";
		try {
			gc.ps = GetConnection.getOracleConn().prepareStatement(sql);
			gc.ps.setInt(1, custId);
			
			return gc.ps.executeUpdate()>0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<Customer> getAllEmps() {
		// TODO Auto-generated method stub
		return null;
	}

}
