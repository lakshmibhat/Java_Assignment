package com.exilant.dao;

import com.exilant.beans.Login;

public class LoginDAO {
	public boolean insertLogin(Login login){
		// we got to connection to db 
		// have a table called login with the attributes 
		// insert it, and return the value as we did in 
		// JDBC 
		return true;
	}
}
